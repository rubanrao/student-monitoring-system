/** Automatically generated file. DO NOT MODIFY */
package com.example.obecnosci_klient_1_0;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}