<?php
$_GET['action']="Request_WyszukajProwadzacego";
$_GET['q']=$_GET['term'];
require_once("admin.api.php");
?>