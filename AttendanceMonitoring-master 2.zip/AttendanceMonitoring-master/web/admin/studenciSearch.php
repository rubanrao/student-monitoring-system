<?php
$_GET['action']="Request_WyszukajStudenta";
$_GET['q']=$_GET['term'];
require_once("admin.api.php");
?>