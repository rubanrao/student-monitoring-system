<?php
header('Location: ../admin.php');

?>