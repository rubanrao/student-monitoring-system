<?php
$_GET['action']="Action_TerminyStempel";
@$_GET['IdZajec']=$_GET['id'];

require_once("admin.api.php");
?>